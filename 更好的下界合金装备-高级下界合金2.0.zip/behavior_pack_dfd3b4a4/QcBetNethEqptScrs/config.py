# -*- coding: utf-8 -*-
mod_name = 'QcBetNethEqptMod'
server_system_name = 'QcBetNethEqptServer'
server_class_path = 'QcBetNethEqptScrs.QcBetNethEqptServer.QcBetNethEqptServer'

