# -*- coding: utf-8 -*-
"""服务端代码控制中心"""
from mod_constants_config import *
import random
import Buddha
import DivineBeast
levelId = ''


class QcBetNethEqptServer(serverApi.GetServerSystemCls()):
    def __init__(self, namespace, name):
        super(QcBetNethEqptServer, self).__init__(namespace, name)
        Buddha.InvokeTheBuddha()
        DivineBeast.SummonTheDivineBeast()
        global levelId
        levelId = serverApi.GetLevelId()
        self.ListenEvent()
        self._add_mob_tick_whitelist()

    # 在类初始化的时候开始监听
    def ListenEvent(self):
        # 注册监听器
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), 'MobDieEvent', self, self.MobDieEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), 'DestroyBlockEvent', self, self.DestroyBlockEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), 'EntityTickServerEvent', self, self.EntityTickServerEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), 'DamageEvent', self, self.DamageEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), 'SpawnProjectileServerEvent', self, self.SpawnProjectileServerEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), 'CraftItemOutputChangeServerEvent', self, self.CraftItemOutputChangeServerEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), 'OnScriptTickServer', self, self.OnScriptTickServer)
        # 使指定事件返回的物品信息字典参数带有userData
        serverApi.GetEngineCompFactory().CreateItem(levelId).GetUserDataInEvent('CraftItemOutputChangeServerEvent')

    # 为需要扫描仇恨目标的敌对生物添加Tick事件白名单
    def _add_mob_tick_whitelist(self):
        for mob in entity_avoid_armor_map:
            serverApi.AddEntityTickEventWhiteList(mob)

    # 取消监听
    def UnListenEvent(self):
        # 反注册监听器
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "MobDieEvent", self, self.MobDieEvent)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "DestroyBlockEvent", self, self.DestroyBlockEvent)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "EntityTickServerEvent", self, self.EntityTickServerEvent)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "DamageEvent", self, self.DamageEvent)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "SpawnProjectileServerEvent", self, self.SpawnProjectileServerEvent)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "CraftItemOutputChangeServerEvent", self, self.CraftItemOutputChangeServerEvent)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnScriptTickServer", self, self.OnScriptTickServer)

    # 在Destroy中调用反注册取消监听
    def Destroy(self):
        self.UnListenEvent()

    # 处理生物被对应武器击杀额外掉落的逻辑
    def MobDieEvent(self, args):
        # 获取事件基本数据
        id = args['id']
        attacker = args['attacker']
        # 获取组件工厂
        compFactory = serverApi.GetEngineCompFactory()
        # 获取实体类型名称
        entity_type = compFactory.CreateEngineType(id).GetEngineTypeStr()
        # 过滤：非有效生物直接返回
        if entity_type not in entity_weapon_map:
            return
        # 获取武器的物品信息
        weapon = compFactory.CreateItem(attacker).GetPlayerItem(mainhand_slot)
        # 过滤：武器不匹配直接返回
        if not (weapon and weapon['newItemName'] in entity_weapon_map[entity_type]):
            return
        # 使用随机数实现50%的触发概率效果
        if random.randint(1,2) == 1:
            # 获取生物死亡点具体位置
            dm = compFactory.CreateDimension(id).GetEntityDimensionId()
            pos = compFactory.CreatePos(id).GetPos()
            # 生成掉落物
            self.CreateEngineItemEntity(entity_loot_table[entity_type], dm, pos)

    # 处理方块被对应工具挖掘额外掉落的逻辑
    def DestroyBlockEvent(self, args):
        # 获取事件基本数据
        blockName = args['fullName']
        auxData = args['auxData']
        playerId = args['playerId']
        # 获取组件工厂
        compFactory = serverApi.GetEngineCompFactory()
        # 过滤：非有效方块直接返回
        if blockName not in block_tool_map:
            return
        # 获取玩家手持工具
        tool_obj = compFactory.CreateItem(playerId).GetPlayerItem(mainhand_slot)
        # 过滤：无工具/工具名不存在 → 直接返回
        if not tool_obj or not tool_obj.get('newItemName'):
            return
        # 获取工具名称字符串
        tool_id = tool_obj['newItemName']
        # 过滤：工具不匹配则直接返回
        if tool_id not in block_tool_map[blockName]:
            return
        # 定义核心判断条件（变量化，提升可读性）
        is_crop = blockName in crops  # 是否是农作物（无论成熟度）
        is_mature_crop = is_crop and auxData >= crop_mature_threshold  # 农作物且成熟
        is_leaves_block = blockName in {'minecraft:oak_leaves', 'minecraft:dark_oak_leaves'}  # 单独判断树叶
        is_ore_block = not (is_crop or is_leaves_block)  # 剩余为矿石方块
        # 按方块类型执行不同的掉落概率逻辑
        trigger_drop = False
        if is_mature_crop or is_leaves_block:
            # 农作物/树叶：按锄头等级的概率触发（百分比计算）
            hoe_prob = hoe_drop_chance_map[tool_id]
            trigger_drop = random.randint(1,10) <= hoe_prob
        elif is_ore_block:
            # 矿石：固定50%概率触发
            trigger_drop = random.randint(1,2) == 1
        # 统一触发掉落逻辑（避免重复代码）
        if trigger_drop:
            # 根据方块名称获取对应掉落物
            loot_item = block_loot_table[blockName]
            # 获取被挖掘方块具体位置
            dm = args['dimensionId']
            pos = (args['x'], args['y'], args['z'])
            # 生成掉落物
            self.CreateEngineItemEntity(loot_item, dm, pos)

    # 每tick扫描列表中的敌对生物来获取仇恨目标
    def EntityTickServerEvent(self, args):
        # 获取事件基本数据
        identifier = args['identifier']
        entityId = args['entityId']
        # 将被多次访问的全局变量的内存指针缓存至局部作用域
        _stunned_tag = stunned_tag
        # 获取组件工厂
        compFactory = serverApi.GetEngineCompFactory()
        # 获取当前生物会避开的盔甲列表
        avoided_armors = entity_avoid_armor_map.get(identifier, ())
        # 获取该生物的仇恨目标
        hate_target = compFactory.CreateAction(entityId).GetAttackTarget()
        # 使用当前entityId创建标签实例
        tag_comp = compFactory.CreateTag(entityId)
        # 过滤：当前生物如果有被仇恨目标攻击过的标签直接清除被震慑标签并返回
        if tag_comp.EntityHasTag('{}{}'.format(attack_tag_prefix, hate_target)):
            tag_comp.RemoveEntityTag(_stunned_tag)
            return
        # 过滤：仇恨目标为空清除所有被攻击标签和被震慑标签并返回
        if hate_target == '-1' or not hate_target:
            tags = tag_comp.GetEntityTags()
            for tag in tags:
                # 如果标签前缀匹配就清除该标签
                if tag.startswith(attack_tag_prefix):
                    tag_comp.RemoveEntityTag(tag)
            # 清除被震慑标签
            tag_comp.RemoveEntityTag(_stunned_tag)
            return
        # 遍历判断：仇恨目标的盔甲是否属于当前生物会避开的盔甲
        for slot in range(4):
            # 获取仇恨目标穿戴盔甲
            hate_target_armor = compFactory.CreateItem(hate_target).GetEntityItem(3, slot)
            # 如果不是有效盔甲直接跳过本轮循环
            if not hate_target_armor or hate_target_armor['newItemName'] not in avoided_armors:
                continue
            # 根据不同生物类型调用对应躲避行为函数
            entity_avoid_armor_funcs[identifier](entityId, hate_target)
            break
        # 如果仇恨目标没有穿戴匹配的盔甲就清除被震慑标签
        else:
            tag_comp.RemoveEntityTag(_stunned_tag)

    # 处理指定生物被攻击后添加标签的逻辑
    def DamageEvent(self, args):
        # 获取事件基本数据
        srcId = args['srcId']
        entityId = args['entityId']
        # 获取组件工厂
        compFactory = serverApi.GetEngineCompFactory()
        # 获取实体类型名称
        entity_type = compFactory.CreateEngineType(entityId).GetEngineTypeStr()
        # 过滤：非有效生物直接返回
        if entity_type not in entity_avoid_armor_map:
            return
        # 过滤：攻击者为空直接返回
        if srcId == '-1' or not srcId:
            return
        # 给被攻击实体添加标签
        compFactory.CreateTag(entityId).AddEntityTag('{}{}'.format(attack_tag_prefix, srcId))
        # 设置仇恨目标
        compFactory.CreateAction(entityId).SetAttackTarget(srcId)

    # 处理拥有被震慑标签的实体不能发射弹射物的逻辑
    def SpawnProjectileServerEvent(self, args):
        # 获取弹射物的发射者
        spawnerId = args['spawnerId']
        # 获取组件工厂
        compFactory = serverApi.GetEngineCompFactory()
        # 判断发射者是否拥有被震慑的标签
        if compFactory.CreateTag(spawnerId).EntityHasTag(stunned_tag):
            # 清除弹射物
            self.DestroyEntity(args['projectileId'])

    # 监听合成物品事件并处理特殊合成逻辑
    def CraftItemOutputChangeServerEvent(self, args):
        # 获取事件基本数据
        itemDict = args['itemDict']
        playerId = args['playerId']
        screenContainerType = args['screenContainerType']
        # 过滤：如果合成结果不是模组内的有效物品直接返回
        if not itemDict or itemDict['newItemName'] not in mod_equipment_items:
            return
        # 过滤：如果容器类型不是物品栏或工作台直接返回
        if not (screenContainerType == 1 or screenContainerType == -1):
            return
        # 将全局变量crafting_slot_id_map的内存指针缓存至局部作用域
        _crafting_slot_id_map = crafting_slot_id_map
        # 创建组件工厂实例与物品组件实例
        compFactory = serverApi.GetEngineCompFactory()
        item_comp = compFactory.CreateItem(playerId)
        # 遍历合成栏里面的物品
        for slot in _crafting_slot_id_map[screenContainerType]:
            crafting_slot_item = item_comp.GetPlayerUIItem(playerId, slot, True)
            # 如果物品为空或物品无userData或物品不是有效物品则直接跳过本轮循环
            if not crafting_slot_item or not crafting_slot_item['userData'] or crafting_slot_item['newItemName'] not in mod_equipment_items:
                continue
            # 取消原版合成结果槽触发逻辑
            args['cancel'] = True
            # 把该合成材料的userData数据删除耐久字段后添加到合成结果的物品信息字典里
            crafting_slot_item['userData'].pop('Damage', None)
            itemDict['userData'] = crafting_slot_item['userData']
            # 获取玩家背包里的所有物品并根据背包空位情况将合成结果生成到对应位置
            inventory_items = item_comp.GetPlayerAllItems(0)
            # 使用try-except捕获index方法造成的ValueError从而判断是否有空位
            try:
                # 有空位时直接生成物品到玩家背包
                air_slot = inventory_items.index(None)
                item_comp.SpawnItemToPlayerInv(itemDict, playerId, air_slot)
            # 没有空位时直接返回
            except ValueError:
                return
            # 发放合成结果后遍历合成栏物品扣减合成所需数量
            for _slot in _crafting_slot_id_map[screenContainerType]:
                # 获取当前合成栏槽位的物品
                crafted_slot_item = item_comp.GetPlayerUIItem(playerId, _slot, True)
                # 如果物品为空则跳过本轮循环
                if not crafted_slot_item:
                    continue
                # 扣除合成消耗的物品数量并更新合成栏槽位UI
                crafted_slot_item['count'] -= itemDict['count']
                item_comp.SetPlayerUIItem(playerId, _slot, crafted_slot_item, False)
            return

    # 在玩家首次进入游戏时给予玩家模组Wiki书本
    def OnScriptTickServer(self):
        # 创建指令实例
        cmd_comp = serverApi.GetEngineCompFactory().CreateCommand(levelId)
        # 运行指令
        cmd_comp.SetCommand('give @a[tag=!qc_has_wiki_book] qc_better_netherite_equipment:bet_neth_equ_mod_wiki')
        cmd_comp.SetCommand('tag @a add qc_has_wiki_book')


