# -*- coding: utf-8 -*-
"""模组常量代码配置文件"""
import mod.server.extraServerApi as serverApi
import math

# 有效生物-对应击杀武器映射表
entity_weapon_map = {
    'minecraft:phantom': {'qc_better_netherite_equipment:e4_netherite_diamond_sword', 'qc_better_netherite_equipment:e1_netherite_iron_sword'},
    'minecraft:zombie_pigman': {'qc_better_netherite_equipment:e4_netherite_diamond_sword', 'qc_better_netherite_equipment:e2_netherite_gold_sword'},
    'minecraft:piglin': {'qc_better_netherite_equipment:e4_netherite_diamond_sword', 'qc_better_netherite_equipment:e2_netherite_gold_sword'},
    'minecraft:enderman': {'qc_better_netherite_equipment:e4_netherite_diamond_sword', 'qc_better_netherite_equipment:e3_netherite_emerald_sword'}
}

# 创建生物掉落物字典
entity_loot_table = {
    'minecraft:phantom': {'count': 1, 'newItemName': 'minecraft:phantom_membrane', 'newAuxValue': 0},
    'minecraft:zombie_pigman': {'count': 1, 'newItemName': 'minecraft:gold_nugget', 'newAuxValue': 0},
    'minecraft:piglin': {'count': 1, 'newItemName': 'minecraft:gold_ingot', 'newAuxValue': 0},
    'minecraft:enderman': {'count': 1, 'newItemName': 'minecraft:ender_pearl', 'newAuxValue': 0}
}

# 公共工具列表
hoe_tools = {
    'qc_better_netherite_equipment:c5_netherite_iron_hoe',
    'qc_better_netherite_equipment:c6_netherite_gold_hoe',
    'qc_better_netherite_equipment:c7_netherite_emerald_hoe',
    'qc_better_netherite_equipment:c8_netherite_diamond_hoe'
}
iron_pickaxe = {'qc_better_netherite_equipment:d1_netherite_iron_pickaxe'}
gold_pickaxe = {'qc_better_netherite_equipment:d2_netherite_gold_pickaxe'}
emerald_pickaxe = {'qc_better_netherite_equipment:d3_netherite_emerald_pickaxe'}
diamond_pickaxe = {'qc_better_netherite_equipment:d4_netherite_diamond_pickaxe'}

# 有效方块-对应挖掘工具映射表
block_tool_map = {
    # 农作物/树叶（锄头）
    'minecraft:potatoes': hoe_tools,
    'minecraft:beetroot': hoe_tools,
    'minecraft:carrots': hoe_tools,
    'minecraft:wheat': hoe_tools,
    'minecraft:oak_leaves': hoe_tools,
    'minecraft:dark_oak_leaves': hoe_tools,
    # 矿石（镐子）
    'minecraft:iron_ore': iron_pickaxe,
    'minecraft:deepslate_iron_ore': iron_pickaxe,
    'minecraft:gold_ore': gold_pickaxe,
    'minecraft:deepslate_gold_ore': gold_pickaxe,
    'minecraft:emerald_ore': emerald_pickaxe,
    'minecraft:deepslate_emerald_ore': emerald_pickaxe,
    'minecraft:diamond_ore': diamond_pickaxe,
    'minecraft:deepslate_diamond_ore': diamond_pickaxe
}

# 农作物列表
crops = {'minecraft:potatoes', 'minecraft:beetroot', 'minecraft:carrots', 'minecraft:wheat'}

# 农作物成熟的auxData阈值
crop_mature_threshold = 7

# 额外掉落物默认配置
default_loot_config = {
    'count': 1,
    'newAuxValue': 0
}

# 方块ID → 掉落物ID 核心映射
block_to_loot_item = {
    # 农作物
    'minecraft:potatoes': 'minecraft:potato',
    'minecraft:beetroot': 'minecraft:beetroot',
    'minecraft:carrots': 'minecraft:carrot',
    'minecraft:wheat': 'minecraft:wheat',
    # 树叶
    'minecraft:oak_leaves': 'minecraft:apple',
    'minecraft:dark_oak_leaves': 'minecraft:apple',
    # 矿石
    'minecraft:iron_ore': 'minecraft:raw_iron',
    'minecraft:deepslate_iron_ore': 'minecraft:raw_iron',
    'minecraft:gold_ore': 'minecraft:raw_gold',
    'minecraft:deepslate_gold_ore': 'minecraft:raw_gold',
    'minecraft:emerald_ore': 'minecraft:emerald',
    'minecraft:deepslate_emerald_ore': 'minecraft:emerald',
    'minecraft:diamond_ore': 'minecraft:diamond',
    'minecraft:deepslate_diamond_ore': 'minecraft:diamond'
}

# 生成最终的掉落物配置字典
block_loot_table = {}
for key, value in block_to_loot_item.items():
    # 创建默认配置的副本（避免影响到原始默认值）
    loot_config = default_loot_config.copy()
    # 给当前方块添加对应的掉落物ID
    loot_config['newItemName'] = value
    # 把配置好的掉落规则存到最终字典里，将对应的方块ID作为key
    block_loot_table[key] = loot_config

# 玩家主手槽位
mainhand_slot = 2

# 不同锄头的概率
hoe_drop_chance_map = {
    'qc_better_netherite_equipment:c5_netherite_iron_hoe': 2,
    'qc_better_netherite_equipment:c6_netherite_gold_hoe': 3,
    'qc_better_netherite_equipment:c7_netherite_emerald_hoe': 4,
    'qc_better_netherite_equipment:c8_netherite_diamond_hoe': 5
}

# 盔甲标识符列表
netherite_diamond_armor = {
    'qc_better_netherite_equipment:b5_netherite_diam_helmet',
    'qc_better_netherite_equipment:b6_netherite_diam_chestplate',
    'qc_better_netherite_equipment:b7_netherite_diam_leggings',
    'qc_better_netherite_equipment:b8_netherite_diam_boots'
}
netherite_emerald_armor = {
    'qc_better_netherite_equipment:b1_netherite_emer_helmet',
    'qc_better_netherite_equipment:b2_netherite_emer_chestplate',
    'qc_better_netherite_equipment:b3_netherite_emer_leggings',
    'qc_better_netherite_equipment:b4_netherite_emer_boots'
}
netherite_gold_armor = {
    'qc_better_netherite_equipment:a5_netherite_gold_helmet',
    'qc_better_netherite_equipment:a6_netherite_gold_chestplate',
    'qc_better_netherite_equipment:a7_netherite_gold_leggings',
    'qc_better_netherite_equipment:a8_netherite_gold_boots'
}
netherite_iron_armor = {
    'qc_better_netherite_equipment:a1_netherite_iron_helmet',
    'qc_better_netherite_equipment:a2_netherite_iron_chestplate',
    'qc_better_netherite_equipment:a3_netherite_iron_leggings',
    'qc_better_netherite_equipment:a4_netherite_iron_boots'
}

# 敌对实体躲避的盔甲映射表
entity_avoid_armor_map = {
    'minecraft:phantom': netherite_diamond_armor | netherite_iron_armor,
    'minecraft:piglin': netherite_diamond_armor | netherite_gold_armor,
    'minecraft:enderman': netherite_diamond_armor | netherite_emerald_armor
}

# 标记实体被特定攻击者攻击过的标签前缀
attack_tag_prefix = 'qc_be_attacked_by_'

# 标记实体被盔甲震慑的标签
stunned_tag = 'qc_be_stunned_by_armor'

# 创建实现控制实体远离另一个实体功能的函数
def EntityRunAway(entityId, target_entity, max_distance, move_distance):
    # 获取组件工厂
    compFactory = serverApi.GetEngineCompFactory()
    # 获取两个实体的坐标位置
    pos = compFactory.CreatePos(entityId).GetPos()
    target_entity_pos = compFactory.CreatePos(target_entity).GetPos()
    # 求两个实体的三维距离
    x1, y1, z1 = pos
    x2, y2, z2 = target_entity_pos
    dx = x1 - x2
    dy = y1 - y2
    dz = z1 - z2
    distance = math.sqrt(dx**2 + dy**2 + dz**2)
    # 如果距离小于等于最大限制距离就触发远离逻辑
    if distance <= max_distance:
        # 两个实体的二维距离
        total_diff = math.sqrt(dx ** 2 + dz ** 2)
        # A和B重合时，给total_diff赋一个极小值，避免除以0
        if total_diff == 0:
            total_diff = 0.01
        # 通过勾股定理计算移动终点的x坐标和z坐标
        new_x = x1 + (dx / total_diff) * move_distance
        new_z = z1 + (dz / total_diff) * move_distance
        # 启动寻路
        compFactory.CreateMoveTo(entityId).SetMoveSetting((new_x, y1, new_z),1.5,200)

# 不同生物躲避穿戴对应盔甲的玩家的行为函数
def piglin_avoiding_armors(entityId, hate_target):  # 猪灵
    # 获取组件工厂
    compFactory = serverApi.GetEngineCompFactory()
    # 获取猪灵手持物品
    item_comp = compFactory.CreateItem(entityId)
    carried_item = item_comp.GetEntityItem(mainhand_slot, getUserData=True)
    # 判断物品是否是弩
    if carried_item and carried_item.get('newItemName') == 'minecraft:crossbow':
        # 取消弩的装填状态
        if carried_item.get('userData'):
            carried_item['userData'].pop('chargedItem', None)
        # 重置猪灵手上的弩
        itemDict = {'count': 1, 'newItemName': 'minecraft:crossbow', 'newAuxValue': 0, 'userData': carried_item.get('userData')}
        item_comp.SetEntityItem(mainhand_slot, itemDict)
    # 调用实体远离函数
    EntityRunAway(entityId, hate_target, 6, 5)
    # 给予猪灵被震慑标签
    compFactory.CreateTag(entityId).AddEntityTag(stunned_tag)

def enderman_avoiding_armors(entityId, hate_target):   # 末影人
    serverApi.GetEngineCompFactory().CreateAction(entityId).SetAttackTarget(entityId)

def phantom_avoiding_armors(entityId, hate_target):   # 幻翼
    serverApi.GetEngineCompFactory().CreateAction(entityId).ResetAttackTarget()

# 实体名称对应躲避函数的映射表
entity_avoid_armor_funcs = {
    'minecraft:piglin': piglin_avoiding_armors,
    'minecraft:enderman': enderman_avoiding_armors,
    'minecraft:phantom': phantom_avoiding_armors
}

# 装备类物品列表
mod_equipment_items = (
    # 盔甲类（4套下界合金盔甲，按材质排序）
    netherite_iron_armor
    | netherite_gold_armor
    | netherite_emerald_armor
    | netherite_diamond_armor
    # 工具类（斧、锄、镐、铲，按工具类型排序）
    | {
        # 斧
        'qc_better_netherite_equipment:c1_netherite_iron_axe',
        'qc_better_netherite_equipment:c2_netherite_gold_axe',
        'qc_better_netherite_equipment:c3_netherite_emerald_axe',
        'qc_better_netherite_equipment:c4_netherite_diamond_axe',
    }
    | hoe_tools  # 锄（已封装为集合，直接并集拼接）
    | (
        # 镐（合并4个材质的镐集合）
        iron_pickaxe
        | gold_pickaxe
        | emerald_pickaxe
        | diamond_pickaxe
    )
    | {
        # 铲
        'qc_better_netherite_equipment:d5_netherite_iron_shovel',
        'qc_better_netherite_equipment:d6_netherite_gold_shovel',
        'qc_better_netherite_equipment:d7_netherite_emerald_shovel',
        'qc_better_netherite_equipment:d8_netherite_diamond_shovel',
    }
    # 武器类（剑）
    | {
        # 剑
        'qc_better_netherite_equipment:e1_netherite_iron_sword',
        'qc_better_netherite_equipment:e2_netherite_gold_sword',
        'qc_better_netherite_equipment:e3_netherite_emerald_sword',
        'qc_better_netherite_equipment:e4_netherite_diamond_sword',
    }
)

# 合成槽位id映射表
crafting_slot_id_map = {
    1: (32, 33, 34, 35, 36, 37, 38, 39, 40),
    -1: (28, 29, 30, 31)
}




